import { supabase } from '@/lib/supabase';
import { NextRequest, NextResponse } from 'next/server';
import { requireSession } from '@/lib/api-auth';

export async function POST(request: NextRequest) {
  try {
    const authResult = await requireSession(request);
    if ('error' in authResult) return authResult.error;

    const body = await request.json();
    const { reporterId, targetId, targetType, reason, description, contactEmail } = body;

    if (!reporterId || !targetId || !targetType || !reason || !description) {
      return NextResponse.json(
        { error: 'reporterId, targetId, targetType, reason, and description are required' },
        { status: 400 }
      );
    }

    const { error } = await supabase.from('reports').insert({
      reporter_id: reporterId,
      target_id: targetId,
      target_type: targetType,
      reason,
      description,
      contact_email: contactEmail || null,
      status: 'PENDING',
    });

    if (error) {
      console.error('Error submitting report:', error.message);
      return NextResponse.json({ error: 'Failed to submit report' }, { status: 500 });
    }

    return NextResponse.json({ success: true, message: 'Report submitted' }, { status: 201 });
  } catch (error) {
    console.error('Error submitting report:', error);
    return NextResponse.json({ error: 'Failed to submit report' }, { status: 500 });
  }
}
