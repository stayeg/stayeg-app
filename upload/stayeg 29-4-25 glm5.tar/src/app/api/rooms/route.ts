import { supabase } from '@/lib/supabase';
import { NextRequest, NextResponse } from 'next/server';
import { requireSession, requireSessionWithRole } from '@/lib/api-auth';

// GET /api/rooms?pgId=...
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const pgId = searchParams.get('pgId');

    if (!pgId) {
      return NextResponse.json({ error: 'pgId is required' }, { status: 400 });
    }

    const { data: rooms, error } = await supabase
      .from('rooms')
      .select('*, beds(*)')
      .eq('pg_id', pgId)
      .order('floor', { ascending: true })
      .order('room_code', { ascending: true });

    if (error) {
      return NextResponse.json({ error: 'Failed to fetch rooms' }, { status: 500 });
    }

    return NextResponse.json(rooms || []);
  } catch {
    return NextResponse.json({ error: 'Failed to fetch rooms' }, { status: 500 });
  }
}

// POST /api/rooms — Create a new room in a PG
export async function POST(request: NextRequest) {
  try {
    // Auth guard: only OWNER and ADMIN can create rooms
    const authResult = await requireSessionWithRole(request, ['OWNER', 'ADMIN']);
    if ('error' in authResult) return authResult.error;

    const body = await request.json();
    const { pgId, roomCode, roomType, floor, hasAC, hasAttachedBath } = body;

    if (!pgId || !roomCode || !roomType) {
      return NextResponse.json(
        { error: 'pgId, roomCode, and roomType are required' },
        { status: 400 }
      );
    }

    const validRoomTypes = ['SINGLE', 'DOUBLE', 'TRIPLE', 'DORMITORY', 'SHARED'];
    if (!validRoomTypes.includes(roomType)) {
      return NextResponse.json(
        { error: `Invalid roomType. Must be one of: ${validRoomTypes.join(', ')}` },
        { status: 400 }
      );
    }

    // Verify the PG exists
    const { data: pg, error: pgError } = await supabase
      .from('pgs')
      .select('id')
      .eq('id', pgId)
      .single();

    if (pgError || !pg) {
      return NextResponse.json({ error: 'PG not found' }, { status: 404 });
    }

    // Check for duplicate room code in the same PG
    const { data: existingRoom } = await supabase
      .from('rooms')
      .select('id')
      .eq('pg_id', pgId)
      .eq('room_code', roomCode)
      .maybeSingle();

    if (existingRoom) {
      return NextResponse.json(
        { error: `Room with code "${roomCode}" already exists in this PG` },
        { status: 409 }
      );
    }

    const { data: room, error } = await supabase
      .from('rooms')
      .insert({
        pg_id: pgId,
        room_code: roomCode,
        room_type: roomType,
        floor: floor ?? 1,
        has_ac: hasAC ?? false,
        has_attached_bath: hasAttachedBath ?? false,
      })
      .select('*, beds(*)')
      .single();

    if (error) throw error;

    return NextResponse.json(room, { status: 201 });
  } catch {
    return NextResponse.json({ error: 'Failed to create room' }, { status: 500 });
  }
}

// PUT /api/rooms — Update a room
export async function PUT(request: NextRequest) {
  try {
    // Auth guard: only OWNER and ADMIN can update rooms
    const authResult = await requireSessionWithRole(request, ['OWNER', 'ADMIN']);
    if ('error' in authResult) return authResult.error;

    const body = await request.json();
    const { id, ...data } = body;

    if (!id) {
      return NextResponse.json({ error: 'id is required' }, { status: 400 });
    }

    const updateData: Record<string, unknown> = {};
    if (data.roomCode !== undefined) updateData.room_code = data.roomCode;
    if (data.roomType !== undefined) updateData.room_type = data.roomType;
    if (data.floor !== undefined) updateData.floor = data.floor;
    if (data.hasAC !== undefined) updateData.has_ac = data.hasAC;
    if (data.hasAttachedBath !== undefined) updateData.has_attached_bath = data.hasAttachedBath;

    const { data: room, error } = await supabase
      .from('rooms')
      .update(updateData)
      .eq('id', id)
      .select('*, beds(*)')
      .single();

    if (error) throw error;

    return NextResponse.json(room);
  } catch {
    return NextResponse.json({ error: 'Failed to update room' }, { status: 500 });
  }
}

// DELETE /api/rooms?roomId=...
export async function DELETE(request: NextRequest) {
  try {
    // Auth guard: only OWNER and ADMIN can delete rooms
    const authResult = await requireSessionWithRole(request, ['OWNER', 'ADMIN']);
    if ('error' in authResult) return authResult.error;

    const { searchParams } = new URL(request.url);
    const roomId = searchParams.get('roomId');

    if (!roomId) {
      return NextResponse.json({ error: 'roomId is required' }, { status: 400 });
    }

    // Check for occupied beds before deleting
    const { data: occupiedBeds } = await supabase
      .from('beds')
      .select('id')
      .eq('room_id', roomId)
      .eq('status', 'OCCUPIED');

    if (occupiedBeds && occupiedBeds.length > 0) {
      return NextResponse.json(
        { error: 'Cannot delete room with occupied beds. Free all beds first.' },
        { status: 400 }
      );
    }

    const { error } = await supabase.from('rooms').delete().eq('id', roomId);

    if (error) throw error;

    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json({ error: 'Failed to delete room' }, { status: 500 });
  }
}
